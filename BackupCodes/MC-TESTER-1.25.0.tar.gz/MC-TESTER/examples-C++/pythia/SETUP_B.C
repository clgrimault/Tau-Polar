{
//look at B+ decays
Setup::decay_particle=521;

Setup::debug_mode=false;

// Setup histograms
int n_bins=60;
double default_min_bin=0.0;
double default_max_bin=6.0; //Max in GeV

Setup::SetHistogramDefaults(n_bins,default_min_bin,default_max_bin);


Setup::gen1_desc_1="Pythia 8.1 demo; p-p at 14 TeV";
Setup::gen1_desc_2="gg->bbbar.  $B+$ decay analysed";
Setup::gen1_desc_3="";

if (Setup::stage==0)
    printf("Setup loaded from SETUP.C, ANALYSIS stage.\n");
else 
    printf("Setup loaded from SETUP.C, GENERATION stage %i.\n",Setup::stage);

Setup::result1_path="mc-tester.root";

Setup::SuppressDecay( 111);
//pi0

Setup::SuppressDecay( 311);
//K0

Setup::SuppressDecay( -311);
//K~0

Setup::SuppressDecay( 321);
//K+

Setup::SuppressDecay( -321);
//K-

Setup::SuppressDecay( 411);
//D+

Setup::SuppressDecay( -411);
//D-

Setup::SuppressDecay( 421);
//D0

Setup::SuppressDecay( -421);
//D~0

Setup::SuppressDecay( 431);
//D_s+

Setup::SuppressDecay( -431);
//D_s-

Setup::SuppressDecay( 511);
//B0

Setup::SuppressDecay( -511);
//B~0

Setup::SuppressDecay( 531);
//B_s0

Setup::SuppressDecay( -531);
//B_s~0

Setup::SuppressDecay( 541);
//B_c+

Setup::SuppressDecay( -541);
//B_c-

Setup::SuppressDecay( 221);
//eta

Setup::SuppressDecay( 331);
//eta'

Setup::SuppressDecay( 441);
//eta_c

Setup::SuppressDecay( 551);
//eta_b

Setup::SuppressDecay( 661);
//eta_t

Setup::SuppressDecay( 130);
//K_L0

Setup::SuppressDecay( 310);
//K_S0

Setup::SuppressDecay( -130);
//K_L~0

Setup::SuppressDecay( -310);
//K_S~0

Setup::SuppressDecay( 213);
//rho+

Setup::SuppressDecay( -213);
//rho-

Setup::SuppressDecay( 313);
//K*0

Setup::SuppressDecay( -313);
//K*~0

Setup::SuppressDecay( 323);
//K*+

Setup::SuppressDecay( -323);
//K*-

Setup::SuppressDecay( 413);
//D*+

Setup::SuppressDecay( -413);
//D*-

Setup::SuppressDecay( 423);
//D*0

Setup::SuppressDecay( -423);
//D*~0

Setup::SuppressDecay( 433);
//D*_s+

Setup::SuppressDecay( -433);
//D*_s-

Setup::SuppressDecay( 513);
//B*0

Setup::SuppressDecay( -513);
//B*~0

Setup::SuppressDecay( 523);
//B*+

Setup::SuppressDecay( -523);
//B*-

Setup::SuppressDecay( 533);
//B*_s0

Setup::SuppressDecay( -533);
//B*_s~0

Setup::SuppressDecay( 543);
//B*_c+

Setup::SuppressDecay( -543);
//B*_c-

Setup::SuppressDecay( 113);
//rho0

Setup::SuppressDecay( 223);
//omega

Setup::SuppressDecay( 333);
//phi

Setup::SuppressDecay( 443);
//J/psi

Setup::SuppressDecay( 553);
//Upsilon

Setup::SuppressDecay( 663);
//Theta

Setup::SuppressDecay( 10213);
//b_1+

Setup::SuppressDecay( -10213);
//b_1-

Setup::SuppressDecay( 10313);
//K_10

Setup::SuppressDecay( -10313);
//K_1~0

Setup::SuppressDecay( 10323);
//K_1+

Setup::SuppressDecay( -10323);
//K_1-

Setup::SuppressDecay( 10413);
//D_1+

Setup::SuppressDecay( -10413);
//D_1-

Setup::SuppressDecay( 10423);
//D_10

Setup::SuppressDecay( -10423);
//D_1~0

Setup::SuppressDecay( 10433);
//D_1s+

Setup::SuppressDecay( -10433);
//D_1s-

Setup::SuppressDecay( 10113);
//b_10

Setup::SuppressDecay( 10223);
//h_10

Setup::SuppressDecay( 10333);
//h'_10

Setup::SuppressDecay( 10443);
//h_1c0

Setup::SuppressDecay( 10211);
//a_0+

Setup::SuppressDecay( -10211);
//a_0-

Setup::SuppressDecay( 10311);
//K*_00

Setup::SuppressDecay( -10311);
//K*_0~0

Setup::SuppressDecay( 10321);
//K*_0+

Setup::SuppressDecay( -10321);
//K*_0-

Setup::SuppressDecay( 10411);
//D*_0+

Setup::SuppressDecay( -10411);
//D*_0-

Setup::SuppressDecay( 10421);
//D*_00

Setup::SuppressDecay( -10421);
//D*_0~0

Setup::SuppressDecay( 10431);
//D*_0s+

Setup::SuppressDecay( -10431);
//D*_0s-

Setup::SuppressDecay( 10111);
//a_00

Setup::SuppressDecay( 10221);
//f_00

Setup::SuppressDecay( 10331);
//f'_00

Setup::SuppressDecay( 10441);
//chi_0c0

Setup::SuppressDecay( 20213);
//a_1+

Setup::SuppressDecay( -20213);
//a_1-

Setup::SuppressDecay( 20313);
//K*_10

Setup::SuppressDecay( -20313);
//K*_1~0

Setup::SuppressDecay( 20323);
//K*_1+

Setup::SuppressDecay( -20323);
//K*_1-

Setup::SuppressDecay( 20413);
//D*_1+

Setup::SuppressDecay( -20413);
//D*_1-

Setup::SuppressDecay( 20423);
//D*_10

Setup::SuppressDecay( -20423);
//D*_1~0

Setup::SuppressDecay( 20433);
//D*_1s+

Setup::SuppressDecay( -20433);
//D*_1s-

Setup::SuppressDecay( 20113);
//a_10

};

