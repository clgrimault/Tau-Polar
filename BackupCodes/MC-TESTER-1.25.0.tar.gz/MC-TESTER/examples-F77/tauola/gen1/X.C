X()
{
    gInterpreter->LoadMacro("TestAnalysis.C");
    TMethodCall useranalysis("TestAnalysis","0,0");
    useranalysis.Execute();
}
