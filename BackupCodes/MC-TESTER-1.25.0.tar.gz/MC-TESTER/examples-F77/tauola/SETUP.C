{
Setup::decay_particle=15;


if (Setup::stage != 0) { // only during generation
    Setup::EVENT=&HEPEVT;
}

//////////////////////////////////////////////////////////
// Setup histograms bounds for 1- 2- ... n-body decays. //
//////////////////////////////////////////////////////////



// default histogram settings:
int n_bins=60;
double default_min_bin=0.0;
double default_max_bin=2.0;

Setup::SetHistogramDefaults(n_bins,default_min_bin,default_max_bin);

Setup::gen1_desc_1="TAUOLA LIBRARY: VERSION XX.YY";
Setup::gen1_desc_2=".............................";
Setup::gen1_desc_3="{\\tt You may replace this text in SETUP.C file.}";


Setup::gen2_desc_1="TAUOLA LIBRARY: VERSION UU.VV";
Setup::gen2_desc_2=".............................";
Setup::gen2_desc_3="{\\tt You may replace this text in SETUP.C file.}";


////////////////////////////////////////////////////////////////////////
// Example of customization:                                          //
// For 4-body decays we want to set range (1,2) for 2-body histograms //
// (3,4) for 3-body histograms and (4.5,4.7) for 4-body histogram:    //
////////////////////////////////////////////////////////////////////////
//
//// 2-body histos of 4-body decay
// Setup::bin_min[4][2]=1;
// Setup::bin_max[4][2]=2;
//
//// 3-body histos of 4-body decay
// Setup::bin_min[4][3]=3;
// Setup::bin_max[4][3]=4;
//
//// 4-body histo of 4-body decay
// Setup::bin_min[4][4]=4.5;
// Setup::bin_max[4][4]=4.7;
//
////////////////////////////////////////////////////////////////////////

if (Setup::stage==0)
    printf("Setup loaded from SETUP.C, ANALYSIS stage.\n");
else 
    printf("Setup loaded from SETUP.C, GENERATION stage %i.\n",Setup::stage);

Setup::SuppressDecay(111); // suppress pi0 decays
//Setup::SuppressDecay(221); // suppress eta decays
//Setup::SuppressDecay(213); // suppress rho+ decays
//Setup::SuppressDecay(-213); // suppress rho- decays


/*
gSystem->AddIncludePath("-I../../../include/");
gSystem->CompileMacro("EnergyThresholdLimit.C");

// set tree analysis function:
Setup::UserTreeAnalysis = "EnergyThresholdLimit";
Setup::UTA_params[0]=0.0; // p_t threshold as fraction of particle energy in mother's frame
Setup::UTA_nparams=1;

//Setup::UserTreeAnalysis = 0;
*/

};

