#include <stdio.h>
#include <assert.h>
#include "MC4Vector.H"

int PtThreshold(HEPParticle *mother,HEPParticleList *stableDaughters)
{
    assert(mother!=0);
    assert(stableDaughters!=0);

    double factor=0.5;    

    HEPParticleListIterator daughters (*stableDaughters);
    for (HEPParticle *part=daughters.first(); part!=0; part=daughters.next() ) {

	MC4Vector d4(part->GetE(),part->GetPx(),part->GetPy(),part->GetPz(),part->GetM());
	// boost to mother's frame:
	d4.Boost(mother->GetPx(),mother->GetPy(),mother->GetPz(),mother->GetE(),mother->GetM());

	double p_t=d4.Xt();
	double limit=factor*mother->GetE();
	
	if (p_t < limit ) {
	    stableDaughters->remove(part);
	}
    }
    
    return 1;
};

