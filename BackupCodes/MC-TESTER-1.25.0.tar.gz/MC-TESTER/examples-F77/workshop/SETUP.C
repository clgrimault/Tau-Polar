{
Setup::gen1_desc_1="pseudogenerator is used";
Setup::gen1_desc_2="demonstration program";
Setup::gen1_desc_3="just one event, kinematic is so-so";
Setup::user_event_analysis=new LC_EventAnalysis();
};
