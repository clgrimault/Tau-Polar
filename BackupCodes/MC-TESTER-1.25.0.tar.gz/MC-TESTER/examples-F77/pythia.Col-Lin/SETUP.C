{
Setup::decay_particle=100;
Setup::gen1_desc_1="Linear Collider MC Workshop test";
Setup::SetHistogramDefaults(120,0,1000);
Setup::user_event_analysis=new LC_EventAnalysis();

Setup::SuppressDecay(111); // suppress pi0 decays

};