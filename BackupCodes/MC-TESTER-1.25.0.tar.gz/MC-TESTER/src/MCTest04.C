/*
   MCTest04 implementation

   This is an example showing how to access bin values, weights and bin errors
   See documentation for details regarding the algorithm
*/

#include <stdio.h>
#include <math.h>
#include "TH1.h"

#include "MCTest04.H"

double MCTest04(TH1D *h1, TH1D *h2) 
{
    // get range of histogram h1
    double h1_min=h1->GetXAxis()->GetXmin();
    double h1_max=h1->GetXAxis()->GetXmax();

    int nbins1=h1->GetNbinsX(); // number of bins in histogram h1
    int nbins2=h2->GetNbinsX(); // number of bins in histogram h2
    
    double integ1=h1->Integral();  // Integral of histogram h1
    double integ2=h2->Intergral(); // Integral of histogram h2

    double sumw1   = h1->GetSumOfWeights(); // Sum of weights in h1
    double maxval1 = h1->GetMaximum(); // Contents of maximum bin in h1
    int    maxbin  = h1->GetMaximumBin(); // Bin with maximal contents in h1
    double minval1 = h1->GetMinimum(); // Contents of minimum bin in h1
    int    minbin  = h1->GetMinimumBin(); // Bin with minimal contents in h1


    // example: find the bin with minimum error (in h1)
    // by looking through all bins in this histogram 
    // return its upper edge:
    double minerr_bin_top=h1_min;
    double minerr_value=999999999;
    
    for (int i=0; i<nbins1; i++) { // loop over all bins of h1
    
	// find the edges, center and width of i'th bin of h1:
	double bin_low_edge   = h1->GetBinLowEdge(i);
	double bin_width      = h1->GetBinWidth(i);
	double bin_center     = h1->GetBinCenter(i);
	double bin_high_edge  = bin_low_edge + bin_width;

	// get contents of i'th bin;
	double bin=h1->GetBinContent(i);   
	// the same could be done by:
	bin=(*h1)[i];

	 // get bin error (calculated by ROOT from sum of weights, etc).
	double bin_err=h1->GetBinError(i);
	
	if (bin_err < minerr_value) {
	    minerr_bin_top=bin_high_edge;
	}
	
    }



// return SDP value:
    double value=0;
    return  value;
}






