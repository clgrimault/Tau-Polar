/*
   MCTesterEvent class implementation
*/
#include "MCTesterEvent.H"

HepevtCommon mctevt_;
MCTesterEvent MCTEVT;



MCTesterEvent::MCTesterEvent() :
HEPEVTEvent((void*)&mctevt_, 2000)
{

}




