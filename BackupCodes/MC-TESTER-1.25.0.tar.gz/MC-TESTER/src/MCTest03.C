/*
   MCTest03 implementation

   See documentation for details regarding the algorithm
*/
#include <stdio.h>
#include <math.h>
#include "TH1.h"

double MCTest03(TH1D *h1, TH1D *h2) 
{
double value=h1->KolmogorovTest(h2);
 value=1-value;
return  value;
}






