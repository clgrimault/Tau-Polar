/*
   MCTest01 implementation

   See documentation for details regarding the algorithm
*/
#include <stdio.h>
#include <math.h>
#include "TH1.h"

double MCTest01 (TH1D *h1, TH1D *h2) 
{
    double suma  =0.0;
    const  int nsumbi=2;   // how many bins into group  
    const double nsigma=3.; // one can change this parameter default is 3 (sigma)

    double int1=h1->Integral();
    double int2=h2->Integral();

    if (int1==0 || int2==0 ) {
	return 300;
    }
    
    
    double diff = int1/int2 ;

   for (int i=0 ; (i+1)*nsumbi < h1->GetNbinsX() ; i++) {      // big loop over new bins
	double n1 = 0.0;
	double n2 = 0.0;
	
	double stand1=1;
	double stand2=1;

        for (int j=1 ; j<=nsumbi ; j++) {                      // small loop inside big bin
 
           int bin = nsumbi*i + j;
           if (bin<=h1->GetNbinsX()){                          // check to stay within histo
            n1+= h1->GetBinContent(bin);
            n2+= h2->GetBinContent(bin);
	  }
          }
      

        if (n1!=0){
	    if (n1!=int1) 
		stand1= sqrt(n1*(1.-n1/int1)) ;
	    else          
		stand1= sqrt(n1*(1.-n1/(int1+1))) ;
        }

        if (n2!=0){
	    if (n2!=int2){
		stand2= sqrt(n2*(1.-n2/int2)) ;
	    }else{
		stand2= sqrt(n2*(1.-n2/(int2+1))) ;
	    }
        }
      
        double stand = stand1 + stand2*diff ;
        stand*=nsigma;

        double DeltaN = fabs(n1-n2*diff) ;

        suma+=(DeltaN - stand > 0 )? (DeltaN - stand) : 0.; 
      
    }

    return suma / int1  ;

}
