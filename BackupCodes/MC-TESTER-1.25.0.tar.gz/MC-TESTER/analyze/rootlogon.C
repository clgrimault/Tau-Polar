{

gSystem.Load("libHist.so");
gSystem.Load("libGpad.so");

TString lib_dir_name=gSystem.Getenv("MC_TESTER_LIBS_DIR");
if(lib_dir_name=="")
  lib_dir_name="../lib/";

gSystem.Load(lib_dir_name+"/libHEPEvent.so");
gSystem.Load(lib_dir_name+"/libMCTester.so");

gROOT->SetStyle("Plain");

}
